package Interfaces;

import java.time.LocalDateTime;

public interface Facturacion {

	public void generarFactura(LocalDateTime salida);
}
