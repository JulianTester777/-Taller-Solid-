package Interfaces;

public interface Detalles {
	
	public void mostrarDetalles();

}
