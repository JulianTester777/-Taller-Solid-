package Interfaces;

import Modells.TipoMembresia;

public interface MembresiaCompra {

	public void comprarMembresia(TipoMembresia tipo);
}
