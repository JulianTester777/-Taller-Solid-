package Interfaces;

import java.util.ArrayList;

import Modells.Vehiculo;

public interface CalculosGenerales {


	
	public double calcularPagoTotal(ArrayList<Vehiculo>vehiculosActuales);

	public double calcularGananciasTotales(ArrayList<Double> montosTotales);
}
