package Modells;

public enum TipoVehiculo {
	
	AUTOMOVIL,
	MOTO,
	CAMION,
	
}
